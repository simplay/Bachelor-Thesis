package Util;

public interface Subscriber {
	public void handleEvent();
}
