package Diffraction;

import java.util.TimerTask;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix4f;

import Listeners.SimpleKeyListener;

import jrtr.RenderPanel;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Quat4f;

public class DiffractionAnimationTask extends TimerTask{
	private DiffractionSceneGraphFabricator dsgf;
	private RenderPanel renderPanel;
	private float tick = (float) (Math.PI/600);
	private float phi;
	
	SimpleKeyListener ks;
	
	private float totalXAngle = 0.0f;
	private float totalYAngle = 0.0f;
	private float totalZAngle = 0.0f;
	private float totalWAngle = 0.0f;
	private float totalYAngle2 = 0.0f;
	private float totalZAngle2 = 0.0f;
	private float totalWAngle2 = 0.0f;
	private float angInc = (float)(Math.PI/50);
	
	public DiffractionAnimationTask(DiffractionSceneGraphFabricator dsgf, RenderPanel renderPanel, SimpleKeyListener ks2){
		this.dsgf = dsgf;
		this.renderPanel = renderPanel;
		this.phi = 0.0f;
		
		this.ks = ks2;
	}
	
	@Override
	public void run() {
//		Matrix4f currentDiffDiceMat = new Matrix4f(dsgf.getDiffPlane());
//		currentDiffDiceMat.mul(dsgf.calculateDiffDiceGroup(phi));
//		dsgf.getDiffDiceGroup().setTransformationMatrix(currentDiffDiceMat);
//		
//		phi = phi + tick;
//		renderPanel.getCanvas().repaint();
		
		
		
		if (ks.inAnim)
		{   /*
			if (totalXAngle < 2*Math.PI) 
			{  // first rotation
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalXAngle = totalXAngle + angInc;
				//angInc *=2;
				
			} 
			
			else if (totalYAngle < Math.PI/6.0f)
			{
				angInc = (float)(Math.PI/500);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalYAngle = totalYAngle + angInc;
			} else if (totalZAngle > - Math.PI/3.0f ) {
				
				angInc = - (float)(Math.PI/500);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalZAngle = totalZAngle + angInc;
			} else if (totalWAngle < Math.PI/6.0f ) {
				angInc =  (float)(Math.PI/500);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalWAngle = totalWAngle + angInc;
			} else 
			*/
			if (totalYAngle2 < Math.PI/9.0f)
			{
				angInc = (float)(Math.PI/10000);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalYAngle2 = totalYAngle2 + angInc;
			} 
			/*
			else if (totalZAngle2 > - Math.PI/22.5f ) {
				
				angInc = - (float)(Math.PI/2000);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalZAngle2 = totalZAngle2 + angInc;
			} else if (totalWAngle2 < Math.PI/45.0f ) {
				angInc =  (float)(Math.PI/10000);
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, angInc));
				totalWAngle2 = totalWAngle2 + angInc;
			} else {
				  totalXAngle = 0.0f;
				  totalYAngle = 0.0f;
				  totalZAngle = 0.0f;
				  totalWAngle = 0.0f;
				  totalYAngle2 = 0.0f;
				  totalZAngle2 = 0.0f;
				  totalWAngle2 = 0.0f;
				  angInc = (float)(Math.PI/100);
				  ks.inAnim = ! ks.inAnim;
								
				
			}
			
			
			/*else if (totalYAngle < Math.PI) 
			{
				ks.rotateLightDirectionAlong(new AxisAngle4f(1.0f, 0.0f, 0.0f, angInc));
				totalYAngle = totalYAngle + angInc;
			}else if (totalZAngle < Math.PI) 
			{
				ks.rotateLightDirectionAlong(new AxisAngle4f(0.0f, 0.0f, 1.0f, angInc));
				totalZAngle = totalZAngle + angInc;
			} else {
				ks.inAnim = !ks.inAnim;
				float totalXAngle = 0.0f;
				float totalYAngle = 0.0f;
				float totalZAngle = 0.0f;				
			}*/
		}
	}

}
