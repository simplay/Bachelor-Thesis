package Listeners;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point2f;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

import jrtr.Light;
import jrtr.RenderItem;
import jrtr.Shape;
import jrtr.RenderPanel;
import jrtr.SceneManagerIterator;
import MVC.MainController;
import SceneGraph.GraphSceneManager;
import SceneGraph.LightNode;
import Diffraction.DiffractionCone;

public class SimpleMouseMotionListener implements MouseMotionListener{
	private Storage s;
	private int width, height;
	private Vector3f v1,v2;
	private float theta;
	private GraphSceneManager sceneManager;
	private RenderPanel renderPanel;
	private MainController controller;
	
	private boolean rotateLight = false;
	
	public SimpleMouseMotionListener(Storage s, GraphSceneManager sceneManager, RenderPanel renderPanel, int width, int height, MainController controller){
		this.s = s;
		this.sceneManager = sceneManager;
		this.renderPanel = renderPanel;
		this.controller = controller;
		this.width = width;
		this.height = height;
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		
		try {
			v1 = s.getV1();
			v2 = s.getV2();
			
			Point2f xy = new Point2f(e.getX(),e.getY());
			int minWH = Math.min(width, height);
			
			// scale bounds to [0,0] - [2,2]
			float x = (xy.getX() - width/2.0f) / (minWH / 2.0f);
			float y = (xy.getY() - height/2.0f) / (minWH / 2.0f);
			
			// translate 0,0 to the center
			//x = x - 1.0f;
			
			// Flip so +Y is up instead of down
			//y = 1.0f - y;
			x = x;
			y =  -y;
			
			//float z2 = 1.0f - x*x - y*y;
			
			float z = 0.0f;
			if (x*x + y*y > 0.5f)
				z = 0.5f / (float) Math.sqrt(x*x + y*y);
			else 
				z = (float) Math.sqrt(1.0 - x*x + y*y);
				
			Vector3f v2New = new Vector3f(x, y, z);
			v2New.normalize();
			
			// calculate axis and angle
		    Vector3f axis = new Vector3f();
		    axis.cross(v1, v2New);    		
		    axis.normalize();
		    
		    // Handles when mouse is outside trackball (x,y)
	//	    theta = v1.angle(v2);
	//	    theta = theta * -1;
		    
		    Vector3f nV1 = v1;
		    nV1.normalize();
		    
		    Vector3f nV2 = v2New;
		    nV2.normalize();
		    
		    float thetaInc = 1.0f;
		    
		    if(Math.abs(v2.dot(nV2)) < 0.001)
		    	throw new java.lang.Exception();
		    
		    Vector3f axisLocal = new Vector3f();
		    axisLocal.cross(v1, nV2);    
		    axisLocal.normalize();
		    
		    
		    theta = (float) Math.acos(nV1.dot(nV2))*thetaInc;
	
		    //if(axis.dot(axisLocal) < 0.0f)
		    	//theta = -theta;
	
		    //Vector3f diff12 = new Vector3f();
		    
		    //diff12.sub(v1, v2New);
		    
		    //theta = (float) diff12.length()*thetaInc;
		    
		    
		    // we have negated the angle theta because we are rotating the camera
		    AxisAngle4f axisaAngle = new AxisAngle4f();
		    //axisaAngle.set(axis, -theta);
		    //if (x < 0.0f )
		    	//axisaAngle.set(axis, theta); // theta is positive since we are rotating Model
		    //else
			    axisaAngle.set(axis, theta); // theta is positive since we are rotating Model
		    	
		    Quat4f delta = new Quat4f();
		    delta.set(axisaAngle);
		    
	//	    // Get current orientation
		    Matrix4f camera = sceneManager.getCamera().getCameraMatrix();
	
			SceneManagerIterator iterator = sceneManager.iterator();	
			while (iterator.hasNext()) 
			{
				RenderItem r = iterator.next(); // assuming there is only one renderItem
				if(r != null)
				{
					Shape s1 = r.getShape();

					// its not null use it
					if (s1.getName() != null && s1.getName().equals("direction cone"))
					{
						// its a scene light rotate it if scenemanager says so
						if(sceneManager.rotateLight())
						{
							// for some reason it has to be a negative angle for light!
							axis.negate();
							axisaAngle.set( axis, theta);
							rotateLightDirectionAlong(axisaAngle);
							
						}
						
					} else if ( !sceneManager.rotateLight())
					{
						// it is not light object and schenmanager does not want to rotate light	
						
					    Matrix4f modelM = s1.getTransformation(); 	
					    Matrix4f modelMOld = new Matrix4f(s1.getTransformation()); 	
				//	    camera.invert();
					    	
					    Quat4f current = new Quat4f();
					    //camera.get(current);
					    modelM.get(current);
					    
					    AxisAngle4f currAA = new AxisAngle4f();
					    
					    currAA.set(modelM);
					    
					    float[] aaF = new float[4];
					    
					    currAA.get(aaF);
					    
					    float nrm = (float)Math.sqrt(aaF[0]*aaF[0] + aaF[1]*aaF[1] + aaF[2]*aaF[2]);
					    
					    Matrix4f currRot = new Matrix4f();
					    if (nrm < 1e-6) {
		
						    currRot.setIdentity();
						    
					    } else 
					    {
						    aaF[0] =aaF[0]/nrm;
						    aaF[1] =aaF[1]/nrm;
						    aaF[2] =aaF[2]/nrm;
						    
						    currAA.set(aaF);
						    
						    currRot.set(currAA);
						    
						    Matrix4f rDelta = new Matrix4f();
						    rDelta.set(delta);
						    rDelta.mulTransposeLeft(currRot, rDelta);
						    rDelta.mul(rDelta, currRot);
						    
						    modelM.mul(modelM, rDelta);
					    }
					    
					    float detValue = modelM.determinant();
					    if(detValue != detValue)
					    {
					    	modelM.setIdentity();
					    	s1.setTransformation(modelMOld);
					    	throw new Exception("Failed To Set Relative Rotation");
					    }
					    
					    	//throw new java.lang.Exception();
					    //sceneManager.getCamera().setCameraMatrix(camera);
					    s1.setTransformation(modelM);
					}
				    //System.out.println("Object transformation Matrix on Trackball is:\n"+ modelM.toString());
				}
				//sceneManager.getCamera().setCameraMatrix(camera);
			}
		    
		    Vector4f pos = new Vector4f();
		    //sceneManager.getCamera().getCameraMatrix().getColumn(3, pos);
		    
		    //System.out.println();
		    //System.out.println("Trackball inverse C_c_w: " + sceneManager.getCamera().getInvC());
		    //System.out.println();
		    
		    // redraw render window (canvas)
		    renderPanel.getCanvas().repaint();
		    /*if(axis.dot(axisLocal) < 0.0f)
		    {
		    	s.setV1(v2);
		    	s.setV2(v2New);
		    } else*/
		    if(v2.dot(v2New) < 0.01f)
		    {
		    	s.setV1(v2);
		    	s.setV2(v2New);
		    } else 
		    {
		    	s.setV1(v2);
		    	s.setV2(v2New);
		    }
		    //else {
				//s.setV1(v2);
				//s.setV2(v2New);
		    //}
		    
	
		} catch (Exception exp111)
		{
		    System.out.println("Exception !!!" + exp111.toString() );
		}
		
		controller.handleEvent();
		
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	private void rotateLightDirectionAlong(AxisAngle4f aa)
	{
    	LightNode light = null;;
    	Vector3f radiance = null;;   	
    	Vector4f oldLightDir = null;;
    	Vector4f newLightDir = null;;
    	Vector3f tmpLightDir = null;;
		LightNode newlight = null;
		Light newlightSource = null;
		
    	light = this.controller.model.dgsf.getLight();
    	radiance = new Vector3f(1,1,1);   	
    	oldLightDir = light.getLightSource().getLightDirection();
    	
    	Quat4f qVal = new Quat4f();
    	
    	qVal.set(aa);
    	
    	Matrix4f mTrans = new Matrix4f();
    	
    	mTrans.set(qVal, new Vector3f(0.0f, 0.0f, 0.0f), 1.0f);
    	
    	newLightDir = new Vector4f();
    	
    	mTrans.transform(oldLightDir, newLightDir);
    	
		newlightSource  = new Light(radiance, newLightDir, "source1");
		newlight = new LightNode(newlightSource, sceneManager.getCamera().getCameraMatrix(), "light source1");		
    	sceneManager.addLight(newlightSource);
    	
    	setLightCone(newLightDir);
		renderPanel.getCanvas().repaint();
	}
	
	
	
	private void setLightCone(Vector4f litDir)
	{
		float[] xyz = new float[4];

		Matrix4f matRot;
		litDir.get(xyz);

		Vector3f v1 = new Vector3f(xyz[0], xyz[1], xyz[2]);
		
		v1.normalize();
		Vector3f vCross = new Vector3f();
		
		Vector3f v2 = new Vector3f(0.0f, 0.0f, -1.0f);
		
		vCross.cross(v1, v2);
		
		if (vCross.length() > 1e-4)
		{
			double angle = Math.acos(v1.dot(v2));
			
			vCross.normalize();
			AxisAngle4f aa = new AxisAngle4f(vCross.getX(), vCross.getY(), vCross.getZ(), (float)angle );
			Quat4f qVal = new Quat4f();
			qVal.set(aa);
			
			matRot = new Matrix4f(qVal, new Vector3f(0.0f, 0.0f, 0.0f), 1.0f);
		} else {
			matRot = new Matrix4f();
			matRot.setIdentity();
		}
		
		SceneManagerIterator iterator = sceneManager.iterator();	
		while(iterator.hasNext()){
			RenderItem r = iterator.next();
			if(r != null && r.getShape()!=null) 
			{
				String shapeName = r.getShape().getName();
				if (shapeName != null && shapeName.equals("direction cone"))
				{
					r.getShape().setTransformation(matRot);
				}
			}
		}
		
	}

}
