package Listeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

import jrtr.Camera;
import jrtr.Light;
import jrtr.RenderItem;
import jrtr.RenderPanel;
import jrtr.SceneManagerIterator;
import Diffraction.DiffractionSceneGraphFabricator;
import MVC.MainController;
import SceneGraph.GraphSceneManager;
import SceneGraph.LightNode;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Quat4f;

import ShaderLogic.TaylorGaussianShaderTask;
import Setup.Managers.ShapeManager;

import java.math.*;

import Constants.ShaderTaskNr;

public class SimpleKeyListener implements KeyListener{
	private Storage s;
	private GraphSceneManager sceneManager;
	private RenderPanel renderPanel;
	private float speed = 0.01f;
	private DiffractionSceneGraphFabricator fabric;
	private float normDiv = 1.0f;
	private float delta_eps = (float) Math.pow(10, -7);
	private MainController controller;
	float eps = 0.1f;
	public boolean inAnim = false;
	
	public SimpleKeyListener(Storage s, GraphSceneManager sceneManager, RenderPanel renderPanel, MainController controller)
	{
		this.s = s;
		this.sceneManager = sceneManager;
		this.renderPanel = renderPanel;
		this.controller = controller;
		
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
	    case KeyEvent.VK_UP:		
	    case KeyEvent.VK_KP_UP:		
	    	sceneManager.incThetaI();
	    	System.out.println("Up key pressed");
	    	renderPanel.getCanvas().repaint();
	    	break;

	    case KeyEvent.VK_DOWN:		
	    	sceneManager.decThetaI();
	    	renderPanel.getCanvas().repaint();
	    	break;

	    case KeyEvent.VK_RIGHT:		
	    	sceneManager.incPhiI();
	    	renderPanel.getCanvas().repaint();
	    	break;

	    case KeyEvent.VK_LEFT:		
	    	sceneManager.decPhiI();
	    	renderPanel.getCanvas().repaint();
			break;
			
		default :
			break;
			
		}		
	}

	@Override
	public void keyReleased(KeyEvent arg0) 
	{
		// TODO Auto-generated method stub
	} 
	
	private void moveLAP(int dir, float amount, boolean backward){
		Point3f new_lap = null;
		
		Camera c = sceneManager.getCamera();
		Point3f cop_old = new Point3f(c.getProjectionCenterPoint());
		Point3f cop_new = null;
	
		if(backward) amount = -amount;
		
		if(dir == 1){
			cop_new = new Point3f(cop_old.x+amount, cop_old.y, cop_old.z);
		}else if(dir == 2){
			cop_new = new Point3f(cop_old.x, cop_old.y+amount, cop_old.z);
		}else if(dir == 3){
			cop_new = new Point3f(cop_old.x, cop_old.y, cop_old.z+amount);
		}
		
		c.setProjectionCenterPoint(cop_new);
		renderPanel.getCanvas().repaint();
	}
	
	
	
//	Matrix4f camera22 = sceneManager.getCamera().getCameraMatrix();
//	Matrix4f rwMatrix22 = new Matrix4f();
//	rwMatrix22.setIdentity();
//	Vector3f rwVector22 = new Vector3f(0f, -speed, 0f);
//	rwMatrix22.setTranslation(rwVector22);
//	camera22.mul(rwMatrix22);
//	sceneManager.getCamera().setCameraMatrix(camera22);
//	renderPanel.getCanvas().repaint();
	
	static int iii = 0;
	@Override
	public void keyTyped(KeyEvent e) {
		
    	LightNode light = null;;
    	Vector3f radiance = null;;   	
    	Vector4f oldLightDir = null;;
    	Vector4f newLightDir = null;;
    	Vector3f tmpLightDir = null;;
		LightNode newlight = null;
		Light newlightSource = null;
		Camera c = null;
		Point3f o_lap = null;
		Point3f new_lap = null;
		
		
		/*
		 * Used up keys
		 * p, n, h, m, w, s, a, d, e, q, t, c, u, j, i, k, o, l, +, -, 
		 */
		
		switch (e.getKeyChar()) {

		case 'p' :


			/* for changing mesh
			 * 
			ShapeManager.snake_file = "../models/ElapheSegmentLowReso.obj";
			System.out.println("Changing file..");
			this.controller.model.dgsf.reinitShape();
	    	renderPanel.getCanvas().repaint();
			*/
			
			/* Task 2 changing to BRDF view
			this.controller.model.dgsf.reinitConfig("sandbox");
			renderPanel.getCanvas().repaint();
			*/
			//if (iii%2 == 0)
				//this.controller.model.dgsf.reinitShaderTask(ShaderTaskNr.TAYLORGAUSSIAN_DIRECT);
			//else
				//this.controller.model.dgsf.reinitShaderTask(ShaderTaskNr.TAYLORGAUSSIAN);
				
			if (iii%2 == 0)
				sceneManager.toggleRenderDirect();
			else
				sceneManager.toggleRenderBRDF();
				
			iii++;
			//else
			//this.controller.model.dgsf.reinitShaderTask(ShaderTaskNr.TAYLORGAUSSIAN);
			
			
			renderPanel.getCanvas().repaint();
			
			break;
			
	    case 'h':		
	    	sceneManager.toggleRotateLight();
			break;

	    case 'm':		
	    	//System.out.println("M for murder!!!");
	    	System.out.println("M changing material!!!");
	    	this.controller.model.dgsf.reinitMaterial();
	    	
	    	((TaylorGaussianShaderTask)this.controller.model.dgsf.activeShaderTask).hasUploadedText = false;
	    	
	    	renderPanel.getCanvas().repaint();
			break;

	    case 'w':		
	    	moveLAP(2, speed, false);
			break;

		    case 's':
		    	moveLAP(2, speed, true);
				break;
	
		    case 'a':
		    	moveLAP(1, speed, false);
				break;
	
		    case 'd':
		    	moveLAP(1, speed, true);
				break;
				
		    case 'e':
		    	moveLAP(3, speed, false);
				break;
				
		    case 'q':
		    	moveLAP(3, speed, true);
				break;
				
		    case 't':
		    	sceneManager.toogleDrawTexture();
				renderPanel.getCanvas().repaint();
				break;
		    	
		    case 'c':
		    	sceneManager.toogleDrawLightCone();

		    	renderPanel.getCanvas().repaint();
				break;
		    	
		    case 'n':
		    	if (sceneManager.getDrawLightCone() == 0)
		    		sceneManager.nextImageDebug();
		    	
		    	
				renderPanel.getCanvas().repaint();
				break;
		    	
		    case 'u':
		    	
		    	//eps = 0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(1.0f, 0.0f, 0.0f, eps));
				break;
				
		    case 'j':
		    	//eps = -0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(1.0f, 0.0f, 0.0f, -eps));
				break;
				
		    case 'i':
		    	//eps = 0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, eps));
				break;
				
		    case 'k':
		    	//eps = -0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(0.0f, 1.0f, 0.0f, -eps));
				break;
				
		    case 'o':
		    	//eps = 0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(0.0f, 0.0f, 1.0f, eps));
				break;
				
		    case 'l':
		    	//eps = -0.1f;
		    	rotateLightDirectionAlong(new AxisAngle4f(0.0f, 0.0f, 1.0f, -eps));
				break;
				
		    case '+':
		    	eps = eps *1.1f;
		    	System.out.println("New Eps is "+eps);
		    	//if(speed < 1.95f)this.speed += 0.05;
				break;
		    case '-':
		    	eps = eps *0.9f;
		    	System.out.println("New Eps is "+eps);
		    	
		    	//if(speed > 0.10f) this.speed -= 0.05;
				break;
		}
		controller.handleEvent();
	}
	
	public void setFabric(DiffractionSceneGraphFabricator fabric){
		this.fabric = fabric;
	}
	
	public void rotateLightDirectionAlong(AxisAngle4f aa)
	{
    	LightNode light = null;;
    	Vector3f radiance = null;;   	
    	Vector4f oldLightDir = null;;
    	Vector4f newLightDir = null;;
    	Vector3f tmpLightDir = null;;
		LightNode newlight = null;
		Light newlightSource = null;
		
    	light = fabric.getLight();
    	radiance = new Vector3f(1,1,1);   	
    	oldLightDir = light.getLightSource().getLightDirection();
    	
    	Quat4f qVal = new Quat4f();
    	
    	qVal.set(aa);
    	
    	Matrix4f mTrans = new Matrix4f();
    	
    	mTrans.set(qVal, new Vector3f(0.0f, 0.0f, 0.0f), 1.0f);
    	
    	newLightDir = new Vector4f();
    	
    	mTrans.transform(oldLightDir, newLightDir);
    	
		newlightSource  = new Light(radiance, newLightDir, "source1");
		newlight = new LightNode(newlightSource, sceneManager.getCamera().getCameraMatrix(), "light source1");		
    	sceneManager.addLight(newlightSource);
    	
    	setLightCone(newLightDir);
		renderPanel.getCanvas().repaint();
		/*
		try {

		    Thread.sleep(10);
		} catch(InterruptedException ex) {
		    Thread.currentThread().interrupt();
		}*/
		
		
	}

	private Vector3f fixVectorForWobel(Vector3f tmpLightDir)
	{
    	tmpLightDir.normalize();
    	
    	if(Math.abs(Math.abs(tmpLightDir.x)-1.0f) < delta_eps ) tmpLightDir.x = 1.0f*Math.signum(tmpLightDir.x);
    	if(Math.abs(Math.abs(tmpLightDir.y)-1.0f) < delta_eps ) tmpLightDir.y = 1.0f*Math.signum(tmpLightDir.y);
    	if(Math.abs(Math.abs(tmpLightDir.z)-1.0f) < delta_eps ) tmpLightDir.z = 1.0f*Math.signum(tmpLightDir.z);
    	
    	if(Math.abs(tmpLightDir.x) < delta_eps ) tmpLightDir.x = 0.0f;
    	if(Math.abs(tmpLightDir.y) < delta_eps ) tmpLightDir.y = 0.0f;
    	if(Math.abs(tmpLightDir.z) < delta_eps ) tmpLightDir.z = 0.0f;
    	
    	tmpLightDir.normalize();

    	return tmpLightDir;
	}
	
	private void setLightCone(Vector4f litDir)
	{
		float[] xyz = new float[4];

		Matrix4f matRot;
		litDir.get(xyz);

		Vector3f v1 = new Vector3f(xyz[0], xyz[1], xyz[2]);
		
		v1.normalize();
		Vector3f vCross = new Vector3f();
		
		Vector3f v2 = new Vector3f(0.0f, 0.0f, -1.0f);
		
		vCross.cross(v1, v2);
		
		if (vCross.length() > 1e-4)
		{
			double angle = Math.acos(v1.dot(v2));
			
			vCross.normalize();
			AxisAngle4f aa = new AxisAngle4f(vCross.getX(), vCross.getY(), vCross.getZ(), (float)angle );
			Quat4f qVal = new Quat4f();
			qVal.set(aa);
			
			matRot = new Matrix4f(qVal, new Vector3f(0.0f, 0.0f, 0.0f), 1.0f);
		} else {
			matRot = new Matrix4f();
			matRot.setIdentity();
		}
		
		SceneManagerIterator iterator = sceneManager.iterator();	
		while(iterator.hasNext()){
			RenderItem r = iterator.next();
			if(r != null && r.getShape()!=null) 
			{
				String shapeName = r.getShape().getName();
				if (shapeName != null && shapeName.equals("direction cone"))
				{
					r.getShape().setTransformation(matRot);
				}
			}
		}
		
	}

}
